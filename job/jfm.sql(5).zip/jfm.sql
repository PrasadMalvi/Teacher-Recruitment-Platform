-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 15, 2014 at 01:53 AM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jfm`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `user_id` int(11) NOT NULL auto_increment,
  `user_name` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY  (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`user_id`, `user_name`, `password`, `type`) VALUES
(2, 'admin', 'admin', 'admin'),
(3, 'jobseeker', 'jobseeker', 'jobseeker'),
(4, 'company', 'company', 'company'),
(5, 'A', '123456', 'jobseeker'),
(7, 'vwg', 'vwg', 'company'),
(8, 'Asiif', '123456', 'jobseeker'),
(9, 'Abcdef', 'Abcdef', 'company'),
(10, 'Rahul', 'rahulhh', 'jobseeker'),
(11, 'My Comp', 'My Comp', 'company'),
(12, 'aaaaaaaaaaaa', '', 'jobseeker'),
(17, '', '', 'jobseeker'),
(18, 'mak', 'mak123', 'jobseeker'),
(19, 'qwerty', 'aaaa123', 'jobseeker'),
(20, 'TCS', 'TCS', 'company'),
(25, 'abc', 'abc', 'company'),
(26, 'sss', 'wwww', 'jobseeker'),
(27, 'Asif', '112233', 'jobseeker');

-- --------------------------------------------------------

--
-- Table structure for table `company_details`
--

CREATE TABLE `company_details` (
  `cmp_id` int(11) NOT NULL auto_increment,
  `cmp_name` varchar(80) NOT NULL,
  `cmp_descrip` varchar(100) NOT NULL,
  `cmp_addr` varchar(100) NOT NULL,
  `contact_person_name` varchar(20) NOT NULL,
  `cmp_phone_no` double NOT NULL,
  `cmp_mobile` double NOT NULL,
  `cmp_e_mail_id` varchar(20) NOT NULL,
  `cmp_website` varchar(20) NOT NULL,
  `cmp_logo` varchar(100) NOT NULL,
  PRIMARY KEY  (`cmp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `company_details`
--

INSERT INTO `company_details` (`cmp_id`, `cmp_name`, `cmp_descrip`, `cmp_addr`, `contact_person_name`, `cmp_phone_no`, `cmp_mobile`, `cmp_e_mail_id`, `cmp_website`, `cmp_logo`) VALUES
(1, 'wipro', 'better', 'bangalore', 'chandru', 6565757454, 5756565664, 'fsfsdfsd@mail.com', 'www.fgdgdg.com', 'wipro-logo.jpg'),
(2, 'tata', 'better', 'new dellhi', 'praveen', 7896325415, 7896321452, 'tata@mail.com', 'www.tata.com', 'TCS.png'),
(3, 'wipro', 'better', 'bangalore', 'shekhar', 6565757454, 5756565664, 'fsfsdfsd@mail.com', 'www.fgdgdg.com', 'wipro-logo.jpg'),
(4, 'zifa', 'better', 'bangalore', 'chandru', 6456644348, 4343444449, 'fdgdj@gmail.com', 'www.sdfydgd.com', 'bank.png'),
(5, 'infosis', 'better', 'pune', 'eijaz', 5896321477, 1478963258, 'ifos@gmail.com', 'www.infosis.com', 'ingy_logo.jpg'),
(6, 'vwg', 'vwg', 'dwd', 'A', 1234567890, 1234567890, 'aaa@gmail.com', 'a', 'A'),
(8, 'Abcdef', 'software', 'dwd', 'qwerty', 2224564567, 4567890456, 'aaa@gmail.com', 'aaa.com', 'A'),
(9, 'My Comp', 'desc', 'Addr', 'abcdef', 1234567890, 1234567890, 'aaa@gmail.com', 'aaa.com', 'admin-icon.gif'),
(10, 'TCS', 'Devt', 'Bangalore', 'abc', 1234567890, 9876543210, 'aaa@gmail.com', 'tcc.com', 'gal3.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `employee_details`
--

CREATE TABLE `employee_details` (
  `emp_id` int(11) NOT NULL auto_increment,
  `js_id` int(11) NOT NULL,
  `jb_opening_id` int(11) NOT NULL,
  `dt_of_recruitment` date NOT NULL,
  `app_id` int(10) NOT NULL,
  `cmp_id` int(10) NOT NULL,
  PRIMARY KEY  (`emp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `employee_details`
--

INSERT INTO `employee_details` (`emp_id`, `js_id`, `jb_opening_id`, `dt_of_recruitment`, `app_id`, `cmp_id`) VALUES
(1, 15, 26, '2014-03-09', 24, 6),
(2, 15, 26, '2014-03-09', 24, 6),
(3, 15, 27, '2014-03-09', 26, 6),
(4, 15, 27, '2014-03-09', 27, 6),
(5, 15, 28, '2014-03-10', 29, 9),
(6, 15, 27, '2014-03-16', 30, 6),
(7, 16, 27, '2014-03-16', 31, 6),
(8, 16, 27, '2014-03-16', 31, 6),
(9, 18, 28, '2014-03-19', 33, 9),
(10, 18, 27, '2014-04-10', 28, 6),
(11, 16, 27, '2014-04-10', 34, 6),
(12, 16, 27, '2014-04-13', 37, 6),
(13, 28, 27, '2014-05-19', 39, 6);

-- --------------------------------------------------------

--
-- Table structure for table `experience_details`
--

CREATE TABLE `experience_details` (
  `exp_id` int(11) NOT NULL auto_increment,
  `js_id` int(11) NOT NULL,
  `exp_name` varchar(50) NOT NULL,
  `exp_descip` varchar(80) NOT NULL,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  PRIMARY KEY  (`exp_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `experience_details`
--

INSERT INTO `experience_details` (`exp_id`, `js_id`, `exp_name`, `exp_descip`, `from_date`, `to_date`) VALUES
(1, 4, 'gfdg', 'gdg', '0000-00-00', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `jb_opening_id` int(11) NOT NULL auto_increment,
  `jb_name` varchar(20) NOT NULL,
  `jb_descrip` varchar(100) NOT NULL,
  `jb_type` varchar(100) NOT NULL,
  `jb_category_id` int(11) NOT NULL,
  `jb_from_date` date NOT NULL,
  `jb_interview_date` date NOT NULL,
  `eligibility` varchar(80) NOT NULL,
  `num_posts` int(11) NOT NULL,
  `last_date_app` date NOT NULL,
  `cmp_id` int(11) NOT NULL,
  `jb_loc_city` varchar(25) NOT NULL,
  `jb_loc_state` varchar(25) NOT NULL,
  `jb_loc_pcode` int(11) NOT NULL,
  PRIMARY KEY  (`jb_opening_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `jobs`
--

INSERT INTO `jobs` (`jb_opening_id`, `jb_name`, `jb_descrip`, `jb_type`, `jb_category_id`, `jb_from_date`, `jb_interview_date`, `eligibility`, `num_posts`, `last_date_app`, `cmp_id`, `jb_loc_city`, `jb_loc_state`, `jb_loc_pcode`) VALUES
(2, 'usgus', 'hello', 'public', 56, '2000-01-11', '2000-09-13', 'abcd', 20, '2000-12-30', 23, '', '', 0),
(3, 'gjewff', 'thtrtt', 'rthrt', 4, '2010-03-04', '2011-03-04', 'fefgee', 2, '2010-12-03', 3, '', '', 0),
(4, 'supervisor', 'good', 'public', 7, '2000-05-07', '2001-07-09', 'degree', 5, '2001-07-07', 4, '', '', 0),
(6, 'zifa', 'good', 'public', 5, '2012-01-07', '2011-05-08', 'bca,mca,m.phill', 6, '1994-08-02', 7, '', '', 0),
(16, 'www', 'www', 'ee', 4, '2014-02-16', '2014-02-16', 'dd', 6, '2014-02-16', 5, '', '', 0),
(19, 'thrh', 'htrhtr', 'trhrh', 4, '0000-00-00', '2014-02-16', 'htrh', 5, '0000-00-00', 1, '', '', 0),
(20, 'zzz', 'q', 'w', 4, '0000-00-00', '2014-02-16', 'qwerty', 10, '2014-02-16', 5, '', '', 0),
(22, 'manager', 'xsaxs', 'sssxx', 1, '2014-02-12', '2014-02-17', 'dcew', 8, '2014-02-07', 4, 'dcf', 'ujgtg', 453456434),
(23, 'manager', 'xsaxs', 'sssxx', 1, '2014-02-12', '2014-02-17', 'dcew', 8, '2014-02-07', 4, 'dcf', 'ujgtg', 12355),
(24, 'manager', 'xsaxs', 'sssxx', 1, '2014-02-12', '2014-02-17', 'dcew', 8, '2014-02-07', 4, 'dcf', 'ujgtg', 12355),
(25, 'general manager', 'management athoriiry', 'goverment', 3, '2014-02-04', '2012-06-06', 'phd', 5, '2014-02-12', 4, 'banglore', 'karnataka', 580024),
(26, 'New Job', 'Dvpt', 'HR', 5, '2014-03-05', '2014-03-31', 'Masters', 10, '2014-03-20', 7, 'dharwad', 'Karnataka', 580007),
(27, 'HR related job', 'desc', 'HR', 5, '2014-03-09', '2014-03-25', 'Degree', 5, '2014-03-15', 6, 'Dharwad', 'Karnataka', 58007),
(28, 'Technician', 'desc', 'type', 5, '2014-03-07', '2014-03-14', 'A', 9, '2014-03-11', 9, 'dharwad', 'Karnataka', 580007);

-- --------------------------------------------------------

--
-- Table structure for table `job_application`
--

CREATE TABLE `job_application` (
  `app_id` int(11) NOT NULL auto_increment,
  `jb_opening_id` int(11) NOT NULL,
  `js_id` int(11) NOT NULL,
  `applied_date` date NOT NULL,
  `status` varchar(50) NOT NULL,
  `cmp_id` int(10) NOT NULL,
  PRIMARY KEY  (`app_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=43 ;

--
-- Dumping data for table `job_application`
--

INSERT INTO `job_application` (`app_id`, `jb_opening_id`, `js_id`, `applied_date`, `status`, `cmp_id`) VALUES
(24, 26, 15, '2014-03-09', 'Recruited', 6),
(25, 25, 15, '2014-03-09', 'Applied', 4),
(26, 27, 15, '2014-03-09', 'Recruited', 6),
(27, 27, 15, '2014-03-09', 'Recruited', 6),
(28, 27, 18, '2014-03-09', 'Recruited', 6),
(29, 28, 15, '2014-03-10', 'Recruited', 9),
(30, 27, 15, '2014-03-16', 'Recruited', 6),
(31, 27, 16, '2014-03-16', 'Recruited', 6),
(32, 22, 18, '2014-03-19', 'Applied', 4),
(33, 28, 18, '2014-03-19', 'Recruited', 9),
(34, 27, 16, '2014-04-10', 'Recruited', 6),
(35, 22, 16, '2014-04-10', 'Applied', 4),
(36, 27, 16, '2014-04-10', 'Applied', 6),
(37, 27, 16, '2014-04-13', 'Recruited', 6),
(38, 24, 18, '2014-04-29', 'Applied', 4),
(39, 27, 28, '2014-05-19', 'Recruited', 6),
(40, 3, 16, '2014-05-21', 'Applied', 3),
(41, 22, 16, '2014-05-21', 'Applied', 4),
(42, 22, 16, '2014-05-21', 'Applied', 4);

-- --------------------------------------------------------

--
-- Table structure for table `job_category`
--

CREATE TABLE `job_category` (
  `jb_category_id` int(11) NOT NULL auto_increment,
  `jb_category` varchar(200) NOT NULL,
  `description` varchar(300) NOT NULL,
  PRIMARY KEY  (`jb_category_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

--
-- Dumping data for table `job_category`
--

INSERT INTO `job_category` (`jb_category_id`, `jb_category`, `description`) VALUES
(1, 'IT', 'bangalore'),
(3, 'FDI', 'its better'),
(4, 'Public', 'hello'),
(5, 'Banking', 'ABC');

-- --------------------------------------------------------

--
-- Table structure for table `job_location`
--

CREATE TABLE `job_location` (
  `jblocation_id` int(11) NOT NULL auto_increment,
  `jb_name` varchar(20) NOT NULL,
  `jb_location` varchar(20) NOT NULL,
  `jb_location_addr` varchar(25) NOT NULL,
  `jb_location_city` varchar(40) NOT NULL,
  `jb_location_pincode` int(11) NOT NULL,
  `jb_location_description` varchar(20) NOT NULL,
  PRIMARY KEY  (`jblocation_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `job_location`
--


-- --------------------------------------------------------

--
-- Table structure for table `job_seeker`
--

CREATE TABLE `job_seeker` (
  `js_id` int(11) NOT NULL auto_increment,
  `js_fname` varchar(50) NOT NULL,
  `js_mname` varchar(30) NOT NULL,
  `js_lname` varchar(50) NOT NULL,
  `js_dob` date NOT NULL,
  `gender` varchar(10) NOT NULL,
  `js_address` varchar(200) NOT NULL,
  `js_city` varchar(20) NOT NULL,
  `js_state` varchar(20) NOT NULL,
  `js_pincode` int(11) NOT NULL,
  `js_phone_no` double NOT NULL,
  `js_mobile_no` double NOT NULL,
  `js_e_mail` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `secret_q` varchar(100) NOT NULL,
  `secret_a` varchar(500) NOT NULL,
  `student_image` varchar(100) NOT NULL,
  PRIMARY KEY  (`js_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `job_seeker`
--

INSERT INTO `job_seeker` (`js_id`, `js_fname`, `js_mname`, `js_lname`, `js_dob`, `gender`, `js_address`, `js_city`, `js_state`, `js_pincode`, `js_phone_no`, `js_mobile_no`, `js_e_mail`, `password`, `secret_q`, `secret_a`, `student_image`) VALUES
(15, 'A', 'B', 'C', '2011-01-10', 'male', 'dwd', 'dwd', 'Karnataka', 111, 321, 321, '', '', '', '', ''),
(16, 'Asiif', 'N', 'K', '2011-10-10', 'male', 'dwd', 'dwd', 'Karnataka', 580006, 12345, 12345, '', '', '', '', ''),
(17, 'idris  ', 'syed', 'syed', '1991-03-27', 'Male', 'megistic', 'banglore', 'karnataka', 52800, 836223344, 9880778661, 'idris@gmail.com', '', '', '', ''),
(18, 'Rahul', 'H', 'H', '1990-10-01', 'female', 'dharwad', 'dharwad', 'Karnataka', 580007, 123456, 9876543210, '', 'rahulhh', 'My First School Name...?', 'joseph', ''),
(19, 'aaaaaaaaaaaa', '', '', '2014-03-17', 'male', '', '', '', 0, 0, 0, '', '', '', '', ''),
(20, 'DJ', 'd', 'j', '2014-03-11', 'male', 'dwd', 'dwd', 'Karnataka', 580007, 1234567890, 9876543210, '', 'employee123', 'My First School Name...?', 'qwerty', ''),
(21, 'qwerty', '', '', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', 'qqq123', '', '', ''),
(22, 'aaaa', '', '', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', 'aaaa123', '', '', ''),
(23, '', '', '', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', '', '', '', ''),
(24, '', '', '', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', '', '', '', ''),
(25, 'mak', 'bbbb', 'aaa', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', 'mak123', '', '', 'Koala.jpg'),
(26, 'qwerty', '', '', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', 'aaaa123', '', '', ''),
(27, 'sss', '', '', '0000-00-00', 'male', '', '', '', 0, 0, 0, '', 'wwww', '', '', ''),
(28, 'Asif', 'K', 'N', '2002-04-08', 'male', 'dwd', 'dwd', 'Andaman and Nicobar ', 555555, 887766, 9743320840, 'asif@gmail.com', '112233', 'My First School Name...?', 'qwerty', 'admin-icon.gif');

-- --------------------------------------------------------

--
-- Table structure for table `qualification_details`
--

CREATE TABLE `qualification_details` (
  `quali_id` int(11) NOT NULL auto_increment,
  `js_id` int(11) NOT NULL,
  `q_name` varchar(50) NOT NULL,
  `university_name` varchar(200) NOT NULL,
  `coll_name` varchar(200) NOT NULL,
  `year_of_passing` varchar(20) NOT NULL,
  `tot_marks` varchar(11) NOT NULL,
  `obtain_marks` varchar(11) NOT NULL,
  `perc` varchar(20) NOT NULL,
  `grade` char(30) NOT NULL,
  PRIMARY KEY  (`quali_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=28 ;

--
-- Dumping data for table `qualification_details`
--

INSERT INTO `qualification_details` (`quali_id`, `js_id`, `q_name`, `university_name`, `coll_name`, `year_of_passing`, `tot_marks`, `obtain_marks`, `perc`, `grade`) VALUES
(1, 1, 'mca', 'kud', 'nehru college', '2018', '700', '620', '88', 'A'),
(2, 1, 'mca', 'kud', 'nehru college', '2018', '700', '620', '88', 'A'),
(6, 4, 'gjgj', 'hgtf', 'hghfg', '2003', '877', '787', '89', 'A'),
(7, 4, 'nggn', 'ghg', 'ththtt', '2000', '643', '788', '90', 'A'),
(8, 6, 'Ajaz', 'XYZ', 'anjuman', '2011', '646', '646', '98', '222'),
(9, 5, 'BCA', 'KUD', 'nehru college', '2007', '700', '675', '98', 'A'),
(10, 3, 'rfghrhg', 'fgfg', 'gfdghf', '2012', '35353', '5454', '90', 'A'),
(11, 6, 'BBA,BCA', 'KUD', 'Nehru BBA & BCA college', '2002', '630', '700', '88', 'A'),
(12, 8, 'bca', 'kud', 'kcd', '2007', '500', '300', '70', 'FCD'),
(13, 8, 'mca', 'vtu', 'bvb', '2010', '500', '400', '78', 'A'),
(14, 9, 'hjgfjhfg', 'jgjgfj', 'gjdgfjf', '2000', '500', '300', '78', 'A'),
(15, 9, 'hthd', 'fhfdh', 'hfdhfdh', '2007', '500', '400', '85', 'A'),
(16, 10, 'mba', 'kud', 'giobal', '2010', '800', '780', '96', 'A'),
(17, 10, 'phd', 'kud', 'gvgnvng', '2005', '600', '500', '87', 'b'),
(18, 14, 'BCA', 'KUD', 'KCD', '2008', '700', '500', '75', 'A'),
(19, 14, 'MCA', 'VTU', 'BVB', '2011', '700', '500', '75', 'A'),
(20, 15, 'A', 'A', 'A', '2011', '100', '100', '100', 'A'),
(21, 16, 'BCA', 'KUD', 'KCD', '2008', '700', '500', '70', 'A'),
(22, 18, 'bba', 'kud', 'kcd', '2000', '700', '600', '85', 'A'),
(23, 19, '', '', '', '', '', '', '', ''),
(24, 20, 'BCA', 'KUD', 'KCD', '2011', '700', '500', '85', 'A'),
(25, 21, 'q', 'e', 'w', '2000', '700', '500', '66', 'firstclass'),
(26, 27, '', '', '', '', '700', '350', '50%', 'secondclass'),
(27, 28, 'mca', 'kk', 'rr', '3333', '600', '500', '83.33333333333334%', 'distinction');
